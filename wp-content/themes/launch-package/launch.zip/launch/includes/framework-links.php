<?php

global $zilla_changelog_link, $zilla_docs_link;
// Theme changelog URL
$zilla_changelog_link = 'http://<changelog_url>';
// Theme documentation URL
$zilla_docs_link = 'http://<docs_url>';

?>