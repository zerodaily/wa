<!--BEGIN .entry-content -->
<div class="entry-content">
	<?php the_content(__('', 'zilla')); ?>
<!--END .entry-content -->
</div>
