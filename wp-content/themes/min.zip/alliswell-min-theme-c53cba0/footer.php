	<div id="footer">
		<p><?php bloginfo('name'); ?> <?php _e('proudly powered by','min'); ?> <a href="http://www.wordpress.org" >Wordpress</a> <?php _e('and','min'); ?> <a href="http://jarederickson.com/2011/min-a-free-wordpress-minimal-theme/">min Theme</a></p>
	</div><!-- close:footer -->
</div><!-- close:wrapper -->
<?php wp_footer(); ?>
</body>
</html>