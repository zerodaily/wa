# min-theme
=========

A minimal WordPress single column theme

![min theme](http://cdn.jarederickson.com/wp-content/uploads/2011/01/min-free-minimal-wordpress-theme-560x390.png)

[Download](http://jarederickson.com/2011/min-a-free-wordpress-minimal-theme/) | [Demo](http://lessmade.com/themes/min)

## v1.2
- Updated URL's to reflect new demo page
- Removed PressTrends tracking

## v1.1
- Updated functions.php with Presstrendeds tracking